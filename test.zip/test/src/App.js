import "./App.css";
import { useEffect } from "react";

function App() {
  useEffect(() => {
    window.open(
      "https://spring-app.auth.ap-south-1.amazoncognito.com/oauth2/authorize?client_id=2r7cqks9bo59crtb9qm1mn3b99&response_type=code&scope=email%20openid%20profile&redirect_uri=https%3A%2F%2Fums-hxzqmgba6q-uc.a.run.app%2Foauth2%2Fcallback&client_secret=14sc5ram1jv85kfqdmua6urh719re5opd50j9pudf0rclpncfneo&identity_provider=personal-azure-ad",
      "_self"
    );
  }, []);

  return <div className="App">Welcome</div>;
}

export default App;
